#import mecessary functions and agent framework
import random 
import matplotlib
matplotlib.use('macosx')
import matplotlib.pyplot
import matplotlib.animation
import csv
import agentframework


#create an empty list for the environment data to be read into
environment = []


#open and read in raster file to create the environment
file = open('in.txt', newline='')
reader = csv.reader(file, quoting=csv.QUOTE_NONNUMERIC)
#append the raster data to the environment list
for row in reader:
    rowlist = []
    for item in row:
        rowlist.append(item)
    environment.append(rowlist)
#close the file after it has been used
file.close()    


#set the initial numbers of agents, iterations, neighbourhood, and store
num_of_agents = 10
num_of_iterations = 100
neighbourhood = 20
store = 0

#create an empty list for the agents data to be appended to
agents = []



#set the initial size for the animated figure
fig = matplotlib.pyplot.figure(figsize = (7,7))
ax = fig.add_axes([0,0,1,1])



#create the agents and assign the necessary information from the agent 
# framework into the agents list, automated for every agent
for i in range(num_of_agents):
    agents.append(agentframework.Agent(environment, agents))



#create a function to animate the agents functions and interactions
def update(frame_number):
    fig.clear()

#run the functions defined in the agent framework whilst randomising the order
# in which the agents are processed
    random.shuffle(agents)       
    for j in range(num_of_iterations):    
        for i in range(num_of_agents):   
            agents[i].walk()
            agents[i].run()
            agents[i].eat()
            agents[i].vom()
            agents[i].share_with_neighbours(neighbourhood)
    
        
#plot the resultant environment map, defining the x and y limits and the colour
# of the agent markers
    matplotlib.pyplot.xlim(0, 300)
    matplotlib.pyplot.ylim(0, 300)
    matplotlib.pyplot.imshow(environment)
    for i in range(num_of_agents):
        matplotlib.pyplot.scatter(agents[i]._x,agents[i]._y, color='white')


#set up animation to show the agents moving and interacting with each other 
# and the environment
animation = matplotlib.animation.FuncAnimation(fig, update, frames=50, 
                                               interval = 1, repeat=True)     
fig.show()



#write out the resultant environment as a csv file
f2 = open('environmentout.csv', 'w', newline='') 
writer = csv.writer(f2)
for row in environment:		
	writer.writerow(row)		
f2.close()

#second file that writes out the total amount stored by the agents, appending
# values to the list each time
f3 = open('stored_food.csv', 'a', newline='')
writer = csv.writer(f3)
for agent in agents:
    total_stored = store + agents[i].store
f3.write(str(total_stored)+"\n")
f3.close()